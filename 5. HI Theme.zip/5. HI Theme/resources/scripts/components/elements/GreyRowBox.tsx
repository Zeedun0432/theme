import styled from 'styled-components/macro';
import tw, { theme } from 'twin.macro';

export default styled.div<{ $hoverable?: boolean }>`
    ${tw`flex rounded no-underline text-neutral-200 items-center bg-neutral-700 p-4 transition duration-150 overflow-hidden`};

    & .icon {
        ${tw`rounded-full bg-neutral-500 p-3`};
    }

    &:active, &:hover, &.active {
        box-shadow: 0 3px ${theme`colors.neutral.900`.toString()};
    }
`;
