import * as React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCogs, faLayerGroup, faSignOutAlt, faUserCircle } from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import SearchContainer from '@/components/dashboard/search/SearchContainer';
import tw, { theme } from 'twin.macro';
import styled from 'styled-components/macro';

const Navigation = styled.div`
    ${tw`w-full overflow-x-auto`};

    & > div {
        ${tw`mx-auto flex items-center`};
        max-width: 1200px;
    }

    & > div > a, & > div > .navigation-link {
        ${tw`text-neutral-200 rounded-xl p-4 text-center text-xl ml-2 mt-3 transition duration-150`};

        &:active, &:hover, &.active {
            box-shadow: inset 0 -3px ${theme`colors.neutral.900`.toString()};
            ${tw`text-neutral-100 bg-neutral-700`};
        }
    }
`;

export default () => {
    const name = useStoreState((state: ApplicationStore) => state.settings.data!.name);
    const rootAdmin = useStoreState((state: ApplicationStore) => state.user.data!.rootAdmin);

    return (
        <Navigation>
              <div>
              <NavLink to={'/'} exact>
                  <FontAwesomeIcon icon={faLayerGroup}/>
              </NavLink>
              <NavLink to={'/account'}>
                  <FontAwesomeIcon icon={faUserCircle}/>
              </NavLink>
              {rootAdmin &&
              <a href={'/admin'} rel={'noreferrer'}>
                  <FontAwesomeIcon icon={faCogs}/>
              </a>
              }
              <a href={'/auth/logout'}>
                  <FontAwesomeIcon icon={faSignOutAlt}/>
              </a>
              </div>
        </Navigation>
    );
};
