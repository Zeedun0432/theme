If you are updating from an earlier version just take the resources file, and then build the panel again.

If there are issues dm me on discord, notil.#2387