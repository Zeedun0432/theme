V1.4.3
 - Improved error messages.
 - Updated Readme.

----

V1.4.2
 - Fixed subnavigation on mobile.
 - Fixed issues.

----

V1.4.1
 - Made subnavigation look better.
 - Changed selected tab color.

----

V1.4
 - Fixed login page errors.
 - Fixed schedules color.

----

V1.3.9
 - Fixed server power action buttons.
 - Improved view on mobile devices.
 - Changed console icon.

----

V1.3.8
 - Themed admin pages.

----

V1.3.7
 - Fixed issues on V1.3.0.

----

V1.3.6
 - Added support for pterodactyl 1.3.0.

----

V1.3.5
 - Removed duplicate selectors.
 - Added back collapsing sidebar.
 - Fixed icon colors and installing status.
 - Fixed text colors.

----

V1.3.4
 - Added cpu limit to ServerDetailsBlock.
 - Changed icon color on ServerDetailsBlock.
 - Fixed text wrapping in some areas.

----

V1.3.3
 - Fixed overlapping.

----

V1.3.2
 - Added credits for theme.

----

V1.3.1
 - Added node to ServerDetailsBlock.
 - Made serverRow look better.

----

V1.3
 - Fixed login page.
 - Fixed unthemed areas.
 - Fixed scaling.
 - Removed smaller sidebar - it caused issues and works fine without it.

----

V1.2
 - Made it easy to change colors.

----

V1.1

 - Fixed scaling on lower resolution devices.
 - Added collapsing sidebar to accommodate lower resolution devices, and allow more space.
