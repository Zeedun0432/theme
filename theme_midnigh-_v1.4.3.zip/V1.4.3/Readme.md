Put the resources folder in /var/www/pterodactyl

After you do that, build the panel.  

You can find more information here.

https://themes.pterodox.com/guides/building.html

Instead of doing "Yarn build:production" do this, "rm -r .babel-plugin-macrosrc.js && yarn add @emotion/react && yarn build:production"

If you want to remove the theme just follow the upgrading guide on pterodactyl's website.

If there are issues or you need help please join my discord, https://discord.gg/HYweeZw3zR

If you want to change colors edit midnight.css in /resources/scripts/midnight.css

There will be variables at the top of the file, change them accordingly, and then build the panel.
