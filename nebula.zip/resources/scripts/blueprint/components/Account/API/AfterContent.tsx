import React from 'react';
/* blueprint/import */

export default () => {
  return (
    <>
      {/* blueprint/react */}
    </>
  );
};
