#!/bin/bash

Command() {
  echo -e "${VERSION}"
}