import React from 'react';
import tw from 'twin.macro';

type Props = Readonly<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement> & {
    title?: string;
    description?: string;
}>;

const PageInfo = ({ title, description, children, ...props }: Props) => (
<div css={tw`mx-auto w-full mt-4`} style={{ maxWidth: '1200px'}}>
    <div css={tw`text-4xl flex `} style={{height: "2.5em"}} {...props}>
    <div css={tw`text-neutral-200 my-auto`} style={{fontSize: "1.6em"}}>
    {children}
    </div>
    <div css={tw`my-auto ml-4`}>
    <h1 css={tw`text-neutral-50 font-semibold text-2xl`}>{title}</h1>
    <p css={tw`text-neutral-300 text-base font-light`}>{description}</p>
    </div>
    </div>
</div>
);

export default PageInfo;
