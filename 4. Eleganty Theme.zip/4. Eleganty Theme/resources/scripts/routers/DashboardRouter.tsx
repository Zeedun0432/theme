import React from 'react';
import { NavLink, Route, RouteComponentProps, Switch } from 'react-router-dom';
import AccountOverviewContainer from '@/components/dashboard/AccountOverviewContainer';
import NavigationBar from '@/components/NavigationBar';
import DashboardContainer from '@/components/dashboard/DashboardContainer';
import AccountApiContainer from '@/components/dashboard/AccountApiContainer';
import { NotFound } from '@/components/elements/ScreenBlock';
import TransitionRouter from '@/TransitionRouter';
import SubNavigation from '@/components/elements/SubNavigation';
import MiniNavigation from '@/components/elements/MiniNavigation';
import PageInfo from '@/components/elements/PageInfo';
import tw from 'twin.macro';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faServer, faUser } from '@fortawesome/free-solid-svg-icons';

export default ({ location }: RouteComponentProps) => (
    <>
        <NavigationBar/>
        <SubNavigation>
            <div>
                <NavLink to={'/'} exact>Servers</NavLink>
                <NavLink to={'/account'}>Account</NavLink>
            </div>
        </SubNavigation>
        {location.pathname.startsWith('/account') &&
        <MiniNavigation>
            <div>
                <NavLink to={'/account'} exact>Settings</NavLink>
                <NavLink to={'/account/api'}>API Credentials</NavLink>
            </div>
        </MiniNavigation>
        }
        <TransitionRouter>
            <Switch location={location}>
                <Route path={'/'} exact>
                    	<div css={tw`mx-4 lg:mx-0`}>
                      <PageInfo title="Servers" description="You can see your servers right here.">
                      <FontAwesomeIcon icon={faServer}/>
                      </PageInfo>
                      </div>
                    <DashboardContainer/>
                </Route>
                <Route path={'/account'} exact>

                <div css={tw`mx-4 lg:mx-0`}>
                <PageInfo title="Account" description="You can manage your account right here.">
                  <FontAwesomeIcon icon={faUser}/>
                </PageInfo>
                </div>
                    <AccountOverviewContainer/>
                </Route>
                <Route path={'/account/api'} exact>
                <PageInfo title="Account" description="You can manage your account right here.">
                  <FontAwesomeIcon icon={faUser}/>
                </PageInfo>
                    <AccountApiContainer/>
                </Route>
                <Route path={'*'}>
                    <NotFound/>
                </Route>
            </Switch>
        </TransitionRouter>
    </>
);
